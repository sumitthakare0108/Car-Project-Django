const productWrapper = document.querySelector('.product-wrapper');
        let translateValue = 0;

        function slide(direction) {
            const productWidth = document.querySelector('.product').offsetWidth;
            if (direction === 'next') {
                translateValue -= productWidth + 40; // 40 is the total margin of .product
            } else if (direction === 'prev') {
                translateValue += productWidth + 40;
            }
            productWrapper.style.transform = `translateX(${translateValue}px)`;
        }
