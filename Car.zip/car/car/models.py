import pymysql
from django.shortcuts import render,redirect
import logging

logger = logging.getLogger(__name__)

def get_database_connection():
    return pymysql.connect(
        host='b4iewagnucfe1s1pe77k-mysql.services.clever-cloud.com',
        user='uui6r0q5trbsqmat',
        password='VMdbyFPJxZ4i2siJ1mYy',
        database='b4iewagnucfe1s1pe77k',
        cursorclass=pymysql.cursors.DictCursor
    )


class Cars:
    def __init__(self):
        self.connection = get_database_connection()

    def authenticate_user(self, userid, password):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("CALL AuthenticateUser(%s, %s, @authenticated, @usertype)", (userid, password))
                cursor.execute("SELECT @authenticated, @usertype")
                result = cursor.fetchone()
                authenticated = result['@authenticated']
                usertype = result['@usertype'] if authenticated else None
                return authenticated, usertype
        except Exception as e:
            print('Exception:', e)
            # Handle exceptions here, e.g., log the error
            return False, None
    
    def signup(self, id, ps, em, na, co, ad, pin, ut="user"):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("CALL InsertUser(%s, %s, %s, %s, %s, %s, %s, %s)",
                               (id, ps, em, na, co, ad, pin, ut))
                self.connection.commit()
                if ut == "user":
                    su = "User registered successfully."
                elif ut == "inspector":
                    su = "Registration successfully. Check your mail for user ID and password."
                else:
                    su = "Registration successfully."
        except Exception as e:
            su = f"User registration failed: {str(e)}"
            # Log the exception for debugging
            print(f"Error in signup method: {str(e)}")
        return su
    
    def check(self,id):
      with self.connection.cursor() as cursor:
         cursor.execute("select * from users where userid='%s'" %id)
         data=cursor.fetchone()
         if data:
            page="checkuser.html"
         else:
            page=None
         self.connection.close()   
         return page
      
    def userrp(self):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT userid, fullnm, email, contact, address, pinno, usertype FROM users WHERE usertype = 'user'")
            data = cursor.fetchall()
            return data
        
    def inprp(self):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT userid, fullnm, email, contact, pinno, usertype FROM users WHERE usertype = 'inspector'")
            data = cursor.fetchall()
            return data    
            
    def newcar(self, uid, mo, co, ye, mi, pr, desc, cond, rto, uploaded_file_url):
        car_id = None
        try:
            with self.connection.cursor() as curs:
                curs.execute("""
                    INSERT INTO cars (seller_userid, model, company, year, mileage, price, descript, cond, rto_doc, photo)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (uid, mo, co, ye, mi, pr, desc, cond, rto, uploaded_file_url))
                self.connection.commit()
                car_id = curs.lastrowid  # Get the last inserted car ID
                msg = "Car Added"
        except Exception as e:
            print(f"Error in inserting car: {e}")
            msg = "Car not added due to an error"
        finally:
            self.connection.close()
        
        return msg, car_id

    def allcar(self, id=None, carid=None):
        try:
            with self.connection.cursor() as curs:
                if carid:
                    curs.execute("SELECT * FROM cars WHERE carid=%s", (carid,))
                    data = curs.fetchone()  # Use fetchone() since we expect only one car
                elif id:
                    curs.execute("SELECT * FROM cars WHERE seller_userid=%s", (id,))
                    data = curs.fetchall()
                else:
                    curs.execute("SELECT * FROM cars")
                    data = curs.fetchall()
        finally:
            self.connection.close()
        return data
       
    def car_detail(self, car_id):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT * FROM cars WHERE carid = %s", (car_id,))
            car = cursor.fetchone()

            cursor.execute("SELECT * FROM cars WHERE carid != %s", (car_id,))
            other_cars = cursor.fetchall()

        return car, other_cars

    def search(self, loc, co, ye):
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT * FROM car WHERE address=%s AND company=%s AND year=%s", (loc, co, ye))
            data = cursor.fetchall()
            return data
        


    def review(self, nm, em, ph, msg):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO review (userid, email, phone, msg) VALUES (%s, %s, %s, %s)",
                    [nm, em, ph, msg]
                )
                self.connection.commit()
            return "Review submitted successfully"
        except Exception as e:
            print(f"Error: {str(e)}")
            return f"Error: {str(e)}"
        
class Inspector:
    def __init__(self):
        self.connection = get_database_connection()

    '''def get_pinno_by_seller_userid(seller_userid):
        with get_database_connection().cursor() as curs:
            curs.execute("SELECT pinno FROM users WHERE userid=%s", (seller_userid,))
            result = curs.fetchone()
        return result['pinno'] if result else None'''
    
    @staticmethod
    def get_inspectors_by_pinno(seller_userid):
        with get_database_connection().cursor() as curs:
            query = """
            SELECT * FROM users 
            WHERE pinno = (SELECT pinno FROM users WHERE userid = %s) 
            AND usertype = 'inspector'
            """
            curs.execute(query, (seller_userid,))
            result = curs.fetchall()
        return result

class InspectionRequest:
    def __init__(self):
        self.connection = get_database_connection()

    def create_request(self, car_id, inspector_id, seller_userid):
        try:
           print("insp=" + inspector_id)
           with self.connection.cursor() as curs:
                curs.execute("""
                    INSERT INTO inspection_request (car_id, inspector_id, user_id, request_status)
                    VALUES (%s, %s, %s, %s)
                    """, (car_id, inspector_id, seller_userid, 'pending'))
                self.connection.commit()
                return "Inspection request created"
        except Exception as e:
            print(f"Error in creating inspection request: {e}")
            return "Error in creating inspection request"
        
    @staticmethod
    def get_inspection_requests_by_inspector(inspector_id):
        try:
            with get_database_connection().cursor() as curs:
                curs.execute("""
                    SELECT ir.request_id, ir.car_id, ir.user_id, ir.request_status, ir.created_at,
                           u.fullnm AS inspector_username
                    FROM inspection_request ir
                    JOIN users u ON ir.inspector_id = u.userid
                    WHERE ir.inspector_id = %s
                """, (inspector_id,))
                inspection_requests = curs.fetchall()
                print(f"Fetched inspection requests for inspector_id {inspector_id}: {inspection_requests}")  # Debug print
            return inspection_requests
        except Exception as e:
            print(f"Error fetching inspection requests: {e}")
            return []

    @staticmethod
    def approve_inspection_request(request_id):
        try:
            with get_database_connection().cursor() as curs:
                curs.execute("""
                    UPDATE inspection_request
                    SET request_status = 'approved'
                    WHERE request_id = %s
                """, [request_id])
                print(f"Approved request_id {request_id}")  # Debug print
        except Exception as e:
            print(f"Error approving inspection request: {e}")

    @staticmethod
    def decline_inspection_request(request_id):
        try:
            with get_database_connection().cursor() as curs:
                curs.execute("""
                    UPDATE inspection_request
                    SET request_status = 'declined'
                    WHERE request_id = %s
                """, [request_id])
                print(f"Declined request_id {request_id}")  # Debug print
        except Exception as e:
            print(f"Error declining inspection request: {e}")