"""
URL configuration for car project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .import views 
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/',views.home,name='home'),
    path('user/',views.user),
    path('log/',views.log),
    path('reg/',views.reg),
    path('signup/',views.signup),
    path('check/',views.check),
    path('',views.home,name='index'),
    path('reg_inspector/', views.reg_inspector, name='reg_inspector'),   
    path('admin_panel/', views.admin_panel, name='admin_panel'),
    path('userrps/', views.userrps, name='userrps'),
    path('inprps/',views.inprps,name='inprps'),
    path('addcar/',views.addcar),
    path('newcar/',views.newcar),
    path('carreport/',views.carreport),
    path('logout/',views.logout_view,name='logout'),
    path('buy/',views.buy),
    path('car/<int:car_id>/', views.car_detail, name='car_detail'),
    path('cars/', views.car_detail, name='car_list'),
    path('feed/', views.feed, name="feed"),
    path('user1/',views.user1),
    path('review/',views.review),
    path('search/',views.search),
    path('inspect/',views.inspect),
    path('send_inspection_request/', views.send_inspection_request, name='send_inspection_request'),
    path('status/', views.status_view, name='status'),
    path('inspector_dashboard/', views.inspector_dashboard, name='inspector_dashboard'),
    path('approve_request/<int:request_id>/', views.approve_inspection, name='approve_request'),
    path('decline_request/<int:request_id>/', views.decline_inspection, name='decline_request'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
