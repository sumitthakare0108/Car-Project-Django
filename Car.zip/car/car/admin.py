from django.contrib import admin
from .models import Inspector

class InspectorAdmin(admin.ModelAdmin):
    list_display = ('userid', 'email')

admin.site.register(Inspector, InspectorAdmin)