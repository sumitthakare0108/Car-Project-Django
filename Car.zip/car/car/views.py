import logging
import random
import string
import os
from .models import Cars, Inspector, InspectionRequest
from . import models
from django.core.mail import send_mail,BadHeaderError
from django.shortcuts import render,redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseBadRequest
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.contrib.auth import logout
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.decorators.csrf import csrf_exempt
 





def home(request):
  obj = Cars()
  cars = obj.allcar()
  return render(request, "index.html", {'cars': cars})

def user(request):
   return render(request,"login.html")

def user1(request):
    return render(request,"user.html")

def log(request):
    if request.method == "POST":
        try:
            id = request.POST.get("userid")
            ps = request.POST.get("password")
            obj = Cars()
            authenticated, usertype = obj.authenticate_user(id, ps)
            
            
            if authenticated:
                if usertype == 'admin':
                    obj1=Cars()
                    data=obj1.allcar()
                    # Redirect to admin panel on successful admin login
                    return render(request,'admin_panel.html',{'cars': data})
                elif usertype == 'user':
                    # Redirect to user page on successful user login
                    request.session['userID'] = id
                    # Get user-specific cars data
                    obj2 = Cars()
                    user_cars = obj2.allcar(id)
                    return render(request, "user.html", {'userid': id, 'cars': user_cars})
                
                elif usertype == 'inspector':
                    # Redirect to inspector-specific page or perform other actions
                    request.session['userID'] = id
                    # Get inspector-specific cars data
                    #obj3 = Cars()
                    #inspector_cars = obj3.allcar(id)
                    return render(request, "inspector_dashboard.html", {'userid': id,}) #'cars': inspector_cars})

                else:
                    return render(request, "fail.html", {'error': 'Unknown user type'})

            else:
                return render(request, "fail.html", {'error': 'Invalid credentials'})
        
        except Exception as e:
            print("Error:", e)
            return render(request, "error.html", {'error': 'An error occurred during authentication. Please try again.'})
    
    else:
        return render(request, "index.html")

def reg(request):
  return render(request,"Singup.html")

def signup(request):
    if request.method == "POST":
        try:
            id = request.POST.get("userid")
            ps = request.POST.get("password")
            em = request.POST.get("email")
            na = request.POST.get("name")
            co = request.POST.get("contact")
            ad = request.POST.get("add")
            pin = request.POST.get("pinno")
            
            obj = Cars()
            su = obj.signup(id, ps, em, na, co, ad, pin)
        except Exception as e:
            # Log the exception for debugging
            print(f"Error in signup: {str(e)}")
            su = "Error in Insert"  

        return render(request, "singupstatus.html", {'status': su})

    # Handle GET request (render signup form)
    return render(request, "signup.html")
    
  #return render(request,"singupstatus.html",dic)

def check(request):
   if request.method=="GET":
      id=request.GET["id"]
      obj=Cars()
      page=obj.check(id)
      return render(request,page) 
   
def admin_panel(request):
    return render(request, 'admin_panel.html')

logger = logging.getLogger(__name__)

def generate_password():
    # Generate a random password of length 8
    password_characters = string.ascii_letters + string.digits 
    return ''.join(random.choice(password_characters) for i in range(8))

def reg_inspector(request):
    if request.method == "POST":
        try:
            id = request.POST.get("userid")
            em = request.POST.get("email")
            na = request.POST.get("fullname")
            co = request.POST.get("contact")
            ad = request.POST.get("add")
            pin = request.POST.get("pinno")
            
            # This method generates a password for the inspector
            ps = generate_password()
            
            # Check if the provided user ID matches the required pattern
            if not id.startswith("INS"):
                raise ValueError("Inspector user ID must start with 'INS'")
            
            obj = Cars()
            su = obj.signup(id, ps, em, na, co, ad, pin, ut="inspector")
            
            if "successfully" in su.lower():
                try:
                    # Send email to inspector with user ID and password
                    send_mail(
                        'Inspector Registration Details',
                        f'Hello {na},\n\nYour registration is successful. Here are your login details:\nUser ID: {id}\nPassword: {ps}\n\nBest Regards,\nAdmin',
                        settings.EMAIL_HOST_USER,  # Admin email
                        [em],
                        fail_silently=False,
                    )
                except BadHeaderError as bhe:
                    logger.error(f"BadHeaderError: {bhe}")
                    signup_status = "Invalid header found."
                except Exception as e:
                    logger.error(f"Error sending email: {str(e)}")
                    signup_status = "Error sending registration email. Please try again later."
            else:
                logger.error(f"Signup failed: {signup_status}")

        except Exception as e:
            logger.error(f"Error in inspector registration: {str(e)}")
            signup_status = 'Error in Registration. Please try again later.'

        return render(request, "inspector_registration_status.html", {'status': su})

    if request.method == "GET":
        return render(request, "reg_inspector.html")

    return HttpResponseBadRequest("Invalid request method")

def userrps(request):
    obj = Cars()
    data = obj.userrp()
    # Print data to the console for debugging
    return render(request, "ushowreport.html", {'userdata': data})

def inprps(request):
    obj = Cars()
    data = obj.inprp()
    # Print data to the console for debugging
    return render(request, "inpshowreport.html", {'userdata': data})

def addcar(request):
    return render(request,"newcar.html")

# views.py
def newcar(request):
    msg = None
    dic = {}

    if request.method == "POST":
        try:
            uid = request.POST.get("sellerid")
            mo = request.POST.get("model")
            co = request.POST.get("company")
            ye = int(request.POST.get("year"))
            mi = float(request.POST.get("mileage"))
            pr = float(request.POST.get("price"))
            desc = request.POST.get("desc")
            cond = request.POST.get("cond")
            rto = request.POST.get("rto_doc")

            if 'photo' in request.FILES:
                photo = request.FILES['photo']
                fs = FileSystemStorage(location=settings.MEDIA_ROOT)
                filename = fs.save(photo.name, photo)
                uploaded_file_url = fs.url(filename)
            else:
                uploaded_file_url = ""  # Or handle this case appropriately

            car_obj = Cars()
            msg, car_id = car_obj.newcar(uid, mo, co, ye, mi, pr, desc, cond, rto, uploaded_file_url)

            # Fetch inspectors based on seller_userid
            inspector_obj = Inspector()
            inspectors = inspector_obj.get_inspectors_by_pinno(uid)

            # Debugging print statements
            print(f"Seller User ID: {uid}")
            print(f"Inspectors: {inspectors}")

            if inspectors:
                dic['inspectors'] = inspectors
            else:
                dic['inspectors'] = []  # No inspectors found

            dic['car_id'] = car_id  # Assign the car_id to the dictionary
            dic['seller_userid'] = uid

        except Exception as e:
            print(e)
            msg = "Error in insert"
        dic['status'] = msg

    return render(request, "status.html", dic)

def carreport(request):
    cars = Cars().allcar()
    paginator = Paginator(cars, 6)  # Show 6 cars per page

    page = request.GET.get('page')
    try:
        cars = paginator.page(page)
    except PageNotAnInteger:
        cars = paginator.page(1)
    except EmptyPage:
        cars = paginator.page(paginator.num_pages)

    return render(request, 'carreport.html', {'cars': cars})
def logout_view(request):
    logout(request)

    return redirect('home')

def buy(request):
    obj = Cars()
    cars = obj.allcar()
    return render(request,"buy_car.html" ,{'cars': cars})



def car_detail(request, car_id):
    cars = Cars()
    car, other_cars = cars.car_detail(car_id)
    cars.connection.close()
    return render(request, 'cars.html', {'car': car, 'cars': other_cars})

def feed(request):
    return render(request, "feed.html")



def search(request):
    data = []  # Initialize the data variable
    if request.method == 'POST':
        try:
            lo = request.POST.get("loc")
            co = request.POST.get("co")
            ye = request.POST.get("year")

            print("Form data - Location:", lo, "Company:", co, "Year:", ye)  # Debugging: print the form data

            if ye is not None and ye != '':
                ye = int(ye)
            else:
                ye = None  # Handle case where year is not provided

            obj = Cars()
            data = obj.search(lo, co, ye)
        except Exception as e:
            print("Error:", e)  # Debugging: print the exception for debugging purposes
    return render(request, "search.html", {'cars': data})  # Use 'cars' instead of 'mini'

def review(request):
    msg = None
    if request.method == 'POST':
        nm = request.POST.get("name")
        em = request.POST.get("email")
        ph = request.POST.get("phone")
        message = request.POST.get("msg")  # Changed variable name to avoid conflict with 'msg'
        
        obj = Cars()
        msg = obj.review(nm, em, ph, message)
        
    return render(request, "user.html", {'msg': msg})

def inspect(request):
    return render(request,"inspector_dashboard.html")


@csrf_exempt
def send_inspection_request(request):
    if request.method == "POST":
        car_id = request.POST.get("car_id")
        inspector_id = request.POST.get("inspector_id")
        seller_userid = request.POST.get("seller_userid")
        print(f"Inspector ID: {inspector_id}")
        
        try:
            # Create an instance of InspectionRequest model
            inspection_request = InspectionRequest()
            
            # Attempt to create the inspection request
            msg = inspection_request.create_request(car_id, inspector_id, seller_userid)

            # Fetch inspectors again based on seller_userid
            inspector_obj = Inspector()
            inspectors = inspector_obj.get_inspectors_by_pinno(seller_userid)

            # Render the status page with a success message
            return render(request, 'status.html', {
                'car_id': car_id,
                'inspectors': inspectors,
                'status': msg
            })

        except Exception as e:
            msg = f"Error in creating inspection request: {e}"
            # Handle error message, perhaps render the status page with an error message
            return render(request, 'status.html', {'status': msg, 'car_id': car_id})

    return redirect('status')  # Adjust as needed

def status_view(request):

    return render(request, "status.html")

def inspector_dashboard(request):
    inspector_id = request.user.userid  # Ensure this is correct and request.user.userid is populated properly
    
    # Fetch inspection requests for the current inspector using the model method
    inspection_requests = InspectionRequest.get_inspection_requests_by_inspector(inspector_id)
    
    print("Inspection requests in context:", inspection_requests)  # Debug print
    
    context = {
        'inspection_requests': inspection_requests
    }
    return render(request, 'inspector_dashboard.html', context)

def approve_inspection(request, request_id):
    if request.method == 'POST':
        InspectionRequest.approve_inspection_request(request_id)
        return redirect('inspector_dashboard')

def decline_inspection(request, request_id):
    if request.method == 'POST':
        InspectionRequest.decline_inspection_request(request_id)
        return redirect('inspector_dashboard')